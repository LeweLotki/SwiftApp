//
//  ClassifierAppApp.swift
//  ClassifierApp
//
//  Created by astefanczyk astefanczyk on 26/11/2024.
//

import SwiftUI

@main
struct ClassifierAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
